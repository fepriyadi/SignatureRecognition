package skripsi.kohonen.signaturerecognition

enum class StatusInput {
    Drawing, Camera, UploadFile
}