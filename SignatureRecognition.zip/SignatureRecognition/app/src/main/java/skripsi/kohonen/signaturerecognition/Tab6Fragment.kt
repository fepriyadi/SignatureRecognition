package skripsi.kohonen.signaturerecognition

import android.support.v4.app.Fragment
import android.view.View

/**
 * A simple [Fragment] subclass.
 */
class Tab6Fragment : Fragment() {
    fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                     savedInstanceState: Bundle?): View {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_tab6, container, false)
    }
}